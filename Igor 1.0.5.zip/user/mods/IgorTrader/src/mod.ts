import { DependencyContainer } from "tsyringe";

// SPT types
import { IPreSptLoadMod } from "@spt/models/external/IPreSptLoadMod";
import { IPostDBLoadMod } from "@spt/models/external/IPostDBLoadMod";
import { ILogger } from "@spt/models/spt/utils/ILogger";
import { PreSptModLoader } from "@spt/loaders/PreSptModLoader";
import { DatabaseServer } from "@spt/servers/DatabaseServer";
import { ImageRouter } from "@spt/routers/ImageRouter";
import { ConfigServer } from "@spt/servers/ConfigServer";
import { ConfigTypes } from "@spt/models/enums/ConfigTypes";
import { ITraderConfig } from "@spt/models/spt/config/ITraderConfig";
import { IRagfairConfig } from "@spt/models/spt/config/IRagfairConfig";
import { JsonUtil } from "@spt/utils/JsonUtil";
import { Money } from "@spt/models/enums/Money";
import { Traders } from "@spt/models/enums/Traders";
import { HashUtil } from "@spt/utils/HashUtil";
import * as path from "path"
// New trader settings
import * as baseJson from "../db/base.json";

import { TraderHelper } from "./traderHelpers";
import { FluentAssortConstructor as FluentAssortCreator } from "./fluentTraderAssortCreator";
const fs = require('fs');
const modPath = path.normalize(path.join(__dirname, '..'));

class SampleTrader implements IPreSptLoadMod, IPostDBLoadMod
{
    private mod: string;
    private logger: ILogger;
    private traderHelper: TraderHelper;
    private fluentAssortCreator: FluentAssortCreator;

    constructor() {
        this.mod = "IgorTrader";
    }

    /**
     * Some work needs to be done prior to SPT code being loaded, registering the profile image + setting trader update time inside the trader config json
     * @param container Dependency container
     */
    public preSptLoad(container: DependencyContainer): void
    {
        // Get a logger
        this.logger = container.resolve<ILogger>("WinstonLogger");
        this.logger.debug(`[${this.mod}] preSpt Loading... `);

        // Get SPT code/data we need later
        const preSptModLoader: PreSptModLoader = container.resolve<PreSptModLoader>("PreSptModLoader");
        const imageRouter: ImageRouter = container.resolve<ImageRouter>("ImageRouter");
        const hashUtil: HashUtil = container.resolve<HashUtil>("HashUtil");
        const configServer = container.resolve<ConfigServer>("ConfigServer");
        const traderConfig: ITraderConfig = configServer.getConfig<ITraderConfig>(ConfigTypes.TRADER);
        const ragfairConfig = configServer.getConfig<IRagfairConfig>(ConfigTypes.RAGFAIR);

        this.traderHelper = new TraderHelper();
        this.fluentAssortCreator = new FluentAssortCreator(hashUtil, this.logger);
        this.traderHelper.registerProfileImage(baseJson, this.mod, preSptModLoader, imageRouter, "igortrader.jpg");
        this.traderHelper.setTraderUpdateTime(traderConfig, baseJson, 3600, 4000);

        Traders[baseJson._id] = baseJson._id;
        ragfairConfig.traders[baseJson._id] = true;
        this.logger.debug(`[${this.mod}] preSpt Loaded`);
    }

    /**
     * Majority of trader-related work occurs after the aki database has been loaded but prior to SPT code being run
     * @param container Dependency container
     */
    public postDBLoad(container: DependencyContainer): void
    {
        this.logger.debug(`[${this.mod}] postDb Loading... `);

        // Resolve SPT classes we'll use
        const databaseServer: DatabaseServer = container.resolve<DatabaseServer>("DatabaseServer");
        const configServer: ConfigServer = container.resolve<ConfigServer>("ConfigServer");
        const jsonUtil: JsonUtil = container.resolve<JsonUtil>("JsonUtil");
        const imageRouter = container.resolve< ImageRouter >("ImageRouter");
        const Wlogger = container.resolve<ILogger>("WinstonLogger");

        // Get a reference to the database tables
        const tables = databaseServer.getTables();

        // Add new trader to the trader dictionary in DatabaseServer - has no assorts (items) yet
        this.traderHelper.addTraderToDb(baseJson, tables, jsonUtil);

        // Add TNT Brick
        this.fluentAssortCreator.createSingleAssortItem("60391b0fb847c71012789415")
                                    .addStackCount(20)
                                    .addMoneyCost(Money.ROUBLES, 24000)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
             
        // Add OFZ Shell
        this.fluentAssortCreator.createSingleAssortItem("5d0379a886f77420407aa271")
                                    .addStackCount(20)
                                    .addMoneyCost(Money.ROUBLES,36000)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);                            
        
        // Add Gunpowder Kite
        this.fluentAssortCreator.createSingleAssortItem("590c5a7286f7747884343aea")
                                    .addStackCount(20)
                                    .addBarterCost("5d0379a886f77420407aa271",1)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
        // Add Gunpowder Eagle
        this.fluentAssortCreator.createSingleAssortItem("5d6fc78386f77449d825f9dc")
                                    .addStackCount(20)
                                    .addMoneyCost(Money.ROUBLES, 32000)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
        // Add Gunpowder Hawk
        this.fluentAssortCreator.createSingleAssortItem("5d6fc87386f77449db3db94e")
                                    .addStackCount(20)
                                    .addBarterCost("5d6fc78386f77449d825f9dc",1)
                                    .addBarterCost("590c5a7286f7747884343aea",1)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);

        // Add Zarya
        this.fluentAssortCreator.createSingleAssortItem("5a0c27731526d80618476ac4")
                                    .addStackCount(200)
                                    .addMoneyCost(Money.ROUBLES, 6999)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
        
        // Add Model 7290
        this.fluentAssortCreator.createSingleAssortItem("619256e5f8af2c1a4e1f5d92")
                                    .addStackCount(100)
                                    .addMoneyCost(Money.ROUBLES, 9750)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);

        // Add RDG-5
        this.fluentAssortCreator.createSingleAssortItem("5448be9a4bdc2dfd2f8b456a")
                                    .addStackCount(75)
                                    .addMoneyCost(Money.ROUBLES, 10000)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
                                    
        // Add F1
        this.fluentAssortCreator.createSingleAssortItem("5710c24ad2720bc3458b45a3")
                                    .addStackCount(35)
                                    .addMoneyCost(Money.ROUBLES, 12000)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
                                                                        
        // Add M67
        this.fluentAssortCreator.createSingleAssortItem("58d3db5386f77426186285a0")
                                    .addStackCount(20)
                                    .addMoneyCost(Money.ROUBLES, 13500)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
        // Add RGN
        this.fluentAssortCreator.createSingleAssortItem("617fd91e5539a84ec44ce155")
                                    .addStackCount(25)
                                    .addMoneyCost(Money.ROUBLES, 20000)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
        // Add RGO
        this.fluentAssortCreator.createSingleAssortItem("618a431df1eb8e24b8741deb")
                                    .addStackCount(25)
                                    .addMoneyCost(Money.ROUBLES, 22000)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
                                                                        
        // Add Grenade Case
        this.fluentAssortCreator.createSingleAssortItem("5e2af55f86f7746d4159f07c")
                                    .addStackCount(5)
                                    .addMoneyCost(Money.ROUBLES, 400000)
                                    .addLoyaltyLevel(2)
                                    .export(tables.traders[baseJson._id]);
                                                                        
        // Add Fuze
        this.fluentAssortCreator.createSingleAssortItem("5e2af51086f7746d3f3c3402")
                                    .addStackCount(300)
                                    .addMoneyCost(Money.ROUBLES, 15000)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
                                                                        
        // Add VOG-17
        this.fluentAssortCreator.createSingleAssortItem("5e32f56fcb6d5863cc5e5ee4")
                                    .addStackCount(100)
                                    .addMoneyCost(Money.ROUBLES, 20000)
                                    .addLoyaltyLevel(2)
                                    .export(tables.traders[baseJson._id]);
        // Add VOG-25
        this.fluentAssortCreator.createSingleAssortItem("5e340dcdcb6d5863cc5e5efb")
                                    .addStackCount(50)
                                    .addMoneyCost(Money.ROUBLES, 27899)
                                    .addLoyaltyLevel(2)
                                    .export(tables.traders[baseJson._id]);
        
        // Add Thermite
        this.fluentAssortCreator.createSingleAssortItem("60391a8b3364dc22b04d0ce5")
                                    .addStackCount(300)
                                    .addMoneyCost(Money.ROUBLES, 35000)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
        // Add Mikor M321 40mm Launcher
        this.fluentAssortCreator.createSingleAssortItem("6275303a9f372d6ea97f9ec7")
                                    .addStackCount(5)
                                    .addMoneyCost(Money.ROUBLES, 450000)
                                    .addLoyaltyLevel(3)
                                    .export(tables.traders[baseJson._id]);
        // Add M32A1 40mm cylinder
        this.fluentAssortCreator.createSingleAssortItem("627bce33f21bc425b06ab967")
                                    .addStackCount(5)
                                    .addMoneyCost(Money.ROUBLES, 30000)
                                    .addLoyaltyLevel(3)
                                    .export(tables.traders[baseJson._id]);                       
        // Add Mikor M2A1 laucnher reflex sight
        this.fluentAssortCreator.createSingleAssortItem("6284bd5f95250a29bc628a30")
                                    .addStackCount(300)
                                    .addMoneyCost(Money.ROUBLES, 20000)
                                    .addLoyaltyLevel(3)
                                    .export(tables.traders[baseJson._id]);
        // Add GP-25 "Kostyor" 40mm Launcher
        this.fluentAssortCreator.createSingleAssortItem("62e7e7bbe6da9612f743f1e0")
                                    .addStackCount(5)
                                    .addMoneyCost(Money.ROUBLES, 40000)
                                    .addLoyaltyLevel(2)
                                    .export(tables.traders[baseJson._id]);
        // Add M203 40mm Launcher
        this.fluentAssortCreator.createSingleAssortItem("6357c98711fb55120211f7e1")
                                    .addStackCount(5)
                                    .addMoneyCost(Money.ROUBLES, 54000)
                                    .addLoyaltyLevel(3)
                                    .export(tables.traders[baseJson._id]);
        // Add 40mm VOG-25
        this.fluentAssortCreator.createSingleAssortItem("5656eb674bdc2d35148b457c")
                                    .addStackCount(120)
                                    .addMoneyCost(Money.ROUBLES, 17999)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
        // Add 40x46mm M406 (HE) grenade
        this.fluentAssortCreator.createSingleAssortItem("5ede4739e0350d05467f73e8")
                                    .addStackCount(300)
                                    .addBarterCost("5d6fc78386f77449d825f9dc",1)
                                    .addBarterCost("60391b0fb847c71012789415",1)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
        // Add 40x46mm M441 (HE) grenade
        this.fluentAssortCreator.createSingleAssortItem("5ede47405b097655935d7d16")
                                    .addStackCount(300)
                                    .addBarterCost("5d6fc78386f77449d825f9dc",1)
                                    .addBarterCost("60391b0fb847c71012789415",1)
                                    .addLoyaltyLevel(2)
                                    .export(tables.traders[baseJson._id]);
        // Add 40x46mm M381 (HE) grenade
        this.fluentAssortCreator.createSingleAssortItem("5ede474b0c226a66f5402622")
                                    .addStackCount(300)
                                    .addBarterCost("60391b0fb847c71012789415",1)
                                    .addBarterCost("590c5a7286f7747884343aea",1)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
        // Add 40x46mm M576 (MP-APERS) grenade
        this.fluentAssortCreator.createSingleAssortItem("5ede475339ee016e8c534742")
                                    .addStackCount(300)
                                    .addBarterCost("60391a8b3364dc22b04d0ce5",1)
                                    .addBarterCost("590c5a7286f7747884343aea",1)
                                    .addBarterCost("5d6fc87386f77449db3db94e",1)
                                    .addLoyaltyLevel(1)
                                    .export(tables.traders[baseJson._id]);
        // Add 40x46mm M386 (HE) grenade
        this.fluentAssortCreator.createSingleAssortItem("5ede475b549eed7c6d5c18fb")
                                    .addStackCount(300)
                                    .addMoneyCost(Money.ROUBLES, 10465)
                                    .addLoyaltyLevel(2)
                                    .export(tables.traders[baseJson._id]);
        // Add 40x46mm M433 (HEDP) grenade
        this.fluentAssortCreator.createSingleAssortItem("5f0c892565703e5c461894e9")
                                    .addStackCount(300)
                                    .addMoneyCost(Money.ROUBLES, 20000)
                                    .addLoyaltyLevel(2)
                                    .export(tables.traders[baseJson._id]);

        
        this.traderHelper.addTraderToLocales(baseJson, tables, baseJson.name, "Igor", baseJson.nickname, baseJson.location, "Former military demolition expert renowned for his expertise in all things explosive. Igor's arsenal of fragmentation grenades and grenade launchers is unmatched, making him the go-to source for the most devastating ordnance in Tarkov's unforgiving battles.");

        //Quests Stuff
        this.importLocales(tables); // Import locales
        this.importQuests(tables,Wlogger); // Import the quest first
        this.importImages(imageRouter,Wlogger); //Import images as the last thing 
        
        this.logger.debug(`[${this.mod}] postDb Loaded`);
    }

    public getFiles(directory,extension,callback)
    {
        if (!fs.existsSync(directory)) return
        const dir = fs.readdirSync(directory, { withFileTypes: true })
        dir.forEach(item => {
            const itemPath = path.normalize(`${directory}/${item.name}`)
            if (item.isDirectory()) this.getFiles(itemPath, extension, callback)
            else if (extension.includes(path.extname(item.name))) callback(itemPath)
        });
    }

    public importQuests(database,logger)
    {
        this.getFiles(`${modPath}/db/quests/`, [".json"], function(filePath) {
            const item = require(filePath)
            if (Object.keys(item).length < 1) return 
            for (const quest in item) 
            {
                database.templates.quests[quest] = item[quest]
            }
        })
    }
    public importLocales(database)
    {
        const serverLocales = ['ch','cz','en','es','es-mx','fr','ge','hu','it','jp','pl','po','ru','sk','tu']
        const addedLocales = {}
        for (const locale of serverLocales) 
        {
            this.getFiles(`${modPath}/db/locales/${locale}`, [".json"], function(filePath) 
            {
                const localeFile = require(filePath)
                if (Object.keys(localeFile).length < 1) return
                for (const currentItem in localeFile) 
                {
                    database.locales.global[locale][currentItem] = localeFile[currentItem]
                    if (!Object.keys(addedLocales).includes(locale)) addedLocales[locale] = {}
                    addedLocales[locale][currentItem] = localeFile[currentItem]
                }
            })
        }
        for (const locale of serverLocales) {
            if (locale == "en") continue
            for (const englishItem in addedLocales["en"]) 
            {
                if (locale in addedLocales) 
                { 
                    if (englishItem in addedLocales[locale]) continue
                }
                if (database.locales.global[locale] != undefined) database.locales.global[locale][englishItem] = addedLocales["en"][englishItem]
            }
        }
    }

    public importImages(router,logger)
    {
        this.getFiles(`${modPath}/res/quests/`, [".png", ".jpg"], function(filePath) 
        {
            router.addRoute(`/files/quest/icon/${path.basename(filePath, path.extname(filePath))}`, filePath);
        })
    }
}

export const mod = new SampleTrader();
